# Word Shovel

A browser game made for GitHub Pages.

## How to play
- Open `index.html` in a browser, or upload it to a GitHub Pages repository.
- You have 72 sandpit cells.
- A few letters begin uncovered.
- Right-click sandy cells to dig up letters.
- Discover all 5 target words before you run out of turns.
- Each discovered word gives 1 point.
- Use the hourglass for a hint.
- Every 2 rounds the vocabulary becomes harder.
- Every 5 rounds, you receive 4 additional turns.

## GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`.
3. Go to **Settings → Pages**.
4. Under the build/deployment settings, select **Deploy from a branch**.
5. Choose the branch containing `index.html` and the root folder.
6. Save and open the GitHub Pages URL after deployment.
